from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api
from flask_cors import CORS


app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///crud.db'
api = Api(app)
db = SQLAlchemy(app)

from app.models.missoes_espaciais import MissoesEspaciais
with app.app_context():
    db.create_all()

from app.view.reso_missoes import MissoesCreate, MissoesUpdate, MissoesDelete, MissoesList
api.add_resource(MissoesCreate, "/create")
api.add_resource(MissoesUpdate, "/update")
api.add_resource(MissoesDelete, "/delete")
api.add_resource(MissoesList, "/search")