from app import db
class MissoesEspaciais(db.Model):
    __tablename_='missoes_espaciais'
    __table_args__={'sqlite_autoincrement':True}
    id = db.Column(db.Integer, primary_key=True)
    nome_missao = db.Column(db.String(250))
    data_lançamento = db.Column(db.Date)
    destino_missao = db.Column(db.String(250))
    estado_da_missao = db.Column(db.String(250))
    tripulaçao = db.Column(db.String(250))
    carga_util = db.Column(db.String(250))
    duraçao_missao = db.Column(db.String(250))
    custo_missao = db.Column(db.Float)
    status_missao = db.Column(db.String(250))

    def __init__(self, nome_missao, data_lançamento, destino_missao, estado_da_missao, tripulaçao, carga_util, duraçao_missao, custo_missao, status_missao):
        self.nome_missao = nome_missao
        self.data_lançamento = data_lançamento
        self.destino_missao = destino_missao
        self.estado_da_missao = estado_da_missao
        self.tripulaçao = tripulaçao
        self.carga_util = carga_util
        self.duraçao_missao = duraçao_missao
        self.custo_missao = custo_missao
        self.status_missao = status_missao
    
    def list_id(self, missao_id):
        try:
            missoes = db.session.query(MissoesEspaciais).filter(MissoesEspaciais.id == missao_id).all()
            missoes_dict = [{'id': missao.id, 'nome_missao':missao.nome_missao, 'data_lançamento':missao.data_lançamneto, 'destino_missao':missao.destino_missao, 'estado_missao':missao.estado_missao, 'tripulaçao':missao.tripulaçao, 'carga_util':missao.carga_util, 'duraçao_missao':missao.duraçao_missao, 'custo_missao':missao.custo_missao, 'status_missao':missao.status_missao} for missao in missoes]

            return missoes_dict
        except Exception as e:
            print(e)
    
    def save_missoes(self, nome_missao, data_lançamento, destino_missao, estado_da_missao, tripulaçao, carga_util, duraçao_missao, custo_missao, status_missao):
        try:
            add_banco = MissoesEspaciais(nome_missao, data_lançamento, destino_missao, estado_da_missao, tripulaçao, carga_util, duraçao_missao, custo_missao, status_missao)
            db.session.add(add_banco)
            db.session.commit()
        except Exception as e:
            print(e)
    
    def update_missoes(self, id, nome_missao, data_lançamento, destino_missao, estado_da_missao, tripulaçao, carga_util, duraçao_missao, custo_missao, status_missao):
        try:
            db.session.query(MissoesEspaciais).filter(MissoesEspaciais.id == id).update({"nome_missao":nome_missao, "data_lançamento":data_lançamento, "destno_missao":destino_missao, "estado_da_missao":estado_da_missao, "tripulaçao":tripulaçao, "carga_util":carga_util, "duraçao_missao":duraçao_missao, "custo_missao":custo_missao})
            db.session.commit()
        except Exception as e:
            print(e)
    
    def delete_missoes(self, id):
        try:
            db.session.query(MissoesEspaciais).filter(MissoesEspaciais.id == id).delete()
            db.session.commit()
        except Exception as e:
            print("Missao não excluida",e)


