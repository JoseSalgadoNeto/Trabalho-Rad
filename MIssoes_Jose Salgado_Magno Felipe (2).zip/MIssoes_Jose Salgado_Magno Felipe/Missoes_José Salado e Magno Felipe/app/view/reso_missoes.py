from flask_restful import Resource, reqparse
from flask import jsonify
from app.models.missoes_espaciais import MissoesEspaciais

argumentos_adicionar = reqparse.RequestParser()
argumentos_adicionar.add_argument('nome_missao', type=str)
argumentos_adicionar.add_argument('data_lançamento', type=str)
argumentos_adicionar.add_argument('destino_missao', type=str)
argumentos_adicionar.add_argument('estado_da_missao', type=str)
argumentos_adicionar.add_argument('tripulaçao', type=str)
argumentos_adicionar.add_argument('carga_util', type=str)
argumentos_adicionar.add_argument('duraçao_missao', type=str)
argumentos_adicionar.add_argument('custo_missao ', type=float)
argumentos_adicionar.add_argument('status_missao', type=str)

arguementos_update = reqparse.RequestParser()
arguementos_update.add_argument('id',type=int)
arguementos_update.add_argument('nome_missao', type=str)
arguementos_update.add_argument('data_lançamento', type=str)
arguementos_update.add_argument('destino_missao', type=str)
arguementos_update.add_argument('estado_da_missao', type=str)
arguementos_update.add_argument('tripulaçao', type=str)
arguementos_update.add_argument('carga_util', type=str)
arguementos_update.add_argument('duraçao_missao', type=str)
arguementos_update.add_argument('custo_missao ', type=float)
arguementos_update.add_argument('status_missao', type=str)

argumentos_delete = reqparse.RequestParser()
argumentos_delete.add_argument('id', type=int)

args = reqparse.RequestParser()
args.add_argument('id', type=int)

class MissoesList(Resource):
    def get(self):
        try:
            datas = args.parse_args()
            missoes = MissoesEspaciais.list_id(self, datas['id'])
            if missoes:
                return missoes
        except Exception as e:
            return jsonify()

class MissoesCreate(Resource):
    def post(self):
        try:
            datas = argumentos_adicionar.parse_args()
            MissoesEspaciais.save_missoes(self, datas['nome_missao'], datas['data_lançamento'], datas['destino_missao'], datas['estado_da_missao'], datas['tripulaçao'], datas['carga_util'], datas['duração_missao'], datas['custo_missao'], datas['status_missao'])
            return {"message": 'Mission create successfully!'}, 200
        except Exception as e:
            return jsonify()
        
class MissoesUpdate(Resource):
    def put(self):
        try:
            datas = arguementos_update.parse_args()
            MissoesEspaciais.update_missoes(self,datas['id'], datas['nome_missao'], datas['data_lançamento'], datas['destino_missao'], datas['estado_da_missao'], datas['tripulaçao'], datas['carga_util'], datas['duração_missao'], datas['custo_missao'], datas['status_missao'])
            return {"message": 'Mission update successfully!'}, 200
        except Exception as e:
            return jsonify()

class MissoesDelete(Resource):
    def delete(self):
        try:
            datas = argumentos_delete.parse_args()
            MissoesEspaciais.delete_missoes(self, datas['id'])
            return {"message": 'Mission deleted successfully!'}, 200
        except Exception as e:
            return jsonify()

